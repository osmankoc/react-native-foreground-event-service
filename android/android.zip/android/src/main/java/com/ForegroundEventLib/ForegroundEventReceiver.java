package com.ForegroundEventLib;

public interface ForegroundEventReceiver {
    void createEventReceiver();

    void registerEventReceiver();
}
